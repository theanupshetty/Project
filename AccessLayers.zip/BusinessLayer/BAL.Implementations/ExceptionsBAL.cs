﻿using DAL.Implementations;
using ORM.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOW.Implementations;

namespace BAL.Implementations
{
   public class ExceptionsBAL
    {
        protected UnitOfWork unitOfWork = new UnitOfWork();
        protected Repository<ExceptionLog> _ExceptionLogsRepository;

        public ExceptionsBAL()
        {
            this._ExceptionLogsRepository = unitOfWork.Repository<ExceptionLog>();
        }

       public IEnumerable<ExceptionLog> Get()
        {
            var list = _ExceptionLogsRepository.GetAll().OrderByDescending(x=>x.ExceptionDate).ToList();
            return list;
        }

      
       public async Task DeleteManyAsync(IEnumerable<ExceptionLog> list)
       {
          await _ExceptionLogsRepository.DeleteManyAsync(list);
       }
    }
}
