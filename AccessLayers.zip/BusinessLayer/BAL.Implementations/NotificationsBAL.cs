﻿using DAL.Implementations;
using ORM.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOW.Implementations;

namespace BAL.Implementations
{
   public class NotificationsBAL
    {
        protected UnitOfWork unitOfWork = new UnitOfWork();
        protected Repository<Notification> _notificationsRepository;

        public NotificationsBAL()
        {
            this._notificationsRepository = unitOfWork.Repository<Notification>();
        }

       public IEnumerable<Notification> Get(string userid)
        {
            var list = _notificationsRepository.GetAll(x => x.UserId == userid && x.IsRead == false).ToList();
            return list;
        }

       public void UpdateMany(string userid)
       {
           var userId = new SqlParameter("@UserId", userid);
           _notificationsRepository.ExcuteSqlQuery("Usp_UpdateNotifications", CommandType.StoredProcedure, parameters: new[] { userId });
       }

       public async Task DeleteManyAsync(IEnumerable<Notification> list)
       {
          await _notificationsRepository.DeleteManyAsync(list);
       }
    }
}
