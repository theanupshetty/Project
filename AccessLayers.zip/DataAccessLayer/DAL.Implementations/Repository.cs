﻿using DAL.Interfaces;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DAL.Implementations
{
    public class Repository<T> : IRepository<T> where T : class
    {
        private DbContext _context = null;
        private DbSet<T> table = null;

        public Repository(DbContext _context)
        {
            this._context = _context;
            table = _context.Set<T>();
        }
        public IEnumerable<T> GetAll(Func<T, bool> predicate = null)
        {
            try
            {
                if (predicate != null)
                {
                    return table.Where(predicate);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return table.ToList();
        }

        public IEnumerable<T> GetAll(int index, int count)
        {
            try
            {
                return table.Skip(index).Take(count).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public T GetById(object id)
        {
            try
            {
                return table.Find(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public async Task<T> GetByIdAsync(object id)
        {
            try
            {
                return await table.FindAsync(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        #region Insert
        public void Insert(T obj)
        {
            try
            {
                table.Add(obj);
                _context.Entry(obj).State = EntityState.Added;
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task InsertAsync(T obj)
        {
            try
            {
                table.Add(obj);
                _context.Entry(obj).State = EntityState.Added;
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void InsertMany(IEnumerable<T> obj)
        {
            try
            {
                table.AddRange(obj);
                _context.Entry(obj).State = EntityState.Added;
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task InsertManyAsync(IEnumerable<T> obj)
        {
            try
            {
                table.AddRange(obj);
                _context.Entry(obj).State = EntityState.Added;
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        public void Update(T obj)
        {
            try
            {
                table.Attach(obj);
                _context.Entry(obj).State = EntityState.Modified;
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task UpdateAsync(T obj)
        {
            try
            {
                table.Attach(obj);
                _context.Entry(obj).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void Delete(object id)
        {
            try
            {
                T existing = table.Find(id);
                table.Remove(existing);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task DeleteAsync(object id)
        {
            try
            {
                T existing = table.Find(id);
                table.Remove(existing);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void DeleteMany(IEnumerable<T> obj)
        {
            try
            {
                table.RemoveRange(obj);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task DeleteManyAsync(IEnumerable<T> obj)
        {
            try
            {
                table.RemoveRange(obj);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ExecuteSqlBulkInsertAsync(IEnumerable<T> obj, string tablename)
        {
            using (var connection = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                using (var bulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.Default, transaction))
                {

                    bulkCopy.BatchSize = 10000;
                    bulkCopy.BulkCopyTimeout = 0;
                    bulkCopy.DestinationTableName = "[dbo].[" + tablename + "]";
                    try
                    {
                        DataTable dt = obj.AsDataTable();
                        await bulkCopy.WriteToServerAsync(dt);
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw ex;
                    }
                    finally
                    {
                        connection.Close();
                    }
                }


            }
        }

        public ICollection ExcuteSqlQuery(string sqlQuery, CommandType commandType, SqlParameter[] parameters = null)
        {
            if (commandType == CommandType.Text)
            {
                return SqlQuery(sqlQuery, parameters);
            }
            else if (commandType == CommandType.StoredProcedure)
            {
                return StoredProcedure(sqlQuery, parameters);
            }

            return null;
        }

        public void ExecuteNonQuery(string commandText, CommandType commandType, SqlParameter[] parameters = null)
        {
            try
            {
                if (_context.Database.Connection.State == ConnectionState.Closed)
                {
                    _context.Database.Connection.Open();
                }

                var command = _context.Database.Connection.CreateCommand();
                command.CommandText = commandText;
                command.CommandType = commandType;

                if (parameters != null)
                {
                    foreach (var parameter in parameters)
                    {
                        command.Parameters.Add(parameter);
                    }
                }

                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public ICollection ExecuteReader(string commandText, CommandType commandType, SqlParameter[] parameters = null)
        {
            try
            {
                if (_context.Database.Connection.State == ConnectionState.Closed)
                {
                    _context.Database.Connection.Open();
                }

                var command = _context.Database.Connection.CreateCommand();
                command.CommandText = commandText;
                command.CommandType = commandType;

                if (parameters != null)
                {
                    foreach (var parameter in parameters)
                    {
                        command.Parameters.Add(parameter);
                    }
                }

                using (var reader = command.ExecuteReader())
                {
                    var mapper = new DataReaderMapper<T>();
                    return mapper.MapToList(reader);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private ICollection SqlQuery(string sqlQuery, object[] parameters = null)
        {
            try
            {
                if (parameters != null && parameters.Any())
                {
                    var parameterNames = new object[parameters.Length];
                    for (int i = 0; i < parameters.Length; i++)
                    {
                        parameterNames[i] = parameters[i];
                    }

                    var result = _context.Database.SqlQuery<T>(string.Format("{0}", sqlQuery, string.Join(",", parameterNames), parameters));
                    return result.ToList();
                }
                else
                {
                    var result = _context.Database.SqlQuery<T>(sqlQuery);
                    return result.ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private ICollection StoredProcedure(string storedProcedureName, SqlParameter[] parameters = null)
        {
            try
            {
                if (parameters != null && parameters.Any())
                {
                    var parameterNames = new object[parameters.Length];
                    for (int i = 0; i < parameters.Length; i++)
                    {
                        parameterNames[i] = parameters[i].Value;
                    }

                    var result = _context.Database.SqlQuery<T>(string.Format("EXEC {0} {1}", storedProcedureName, string.Join(",", parameterNames), parameters));
                    return result.ToList();
                }
                else
                {
                    var result = _context.Database.SqlQuery<T>(string.Format("EXEC {0}", storedProcedureName));
                    return result.ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
