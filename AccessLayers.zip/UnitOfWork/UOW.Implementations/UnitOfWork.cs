﻿using DAL.Implementations;
using ORM.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UOW.Interfaces;

namespace UOW.Implementations
{
    public partial class UnitOfWork : IUnitOfWork
    {
        private WebApplicationContext dbContext = null;
        private bool disposed;
        private Dictionary<string, object> repositories;

        public UnitOfWork()
        {
            this.dbContext = new WebApplicationContext();
        }
        public UnitOfWork(WebApplicationContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        public virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    dbContext.Dispose();
                }
            }
            disposed = true;
        }

        public Repository<T> Repository<T>() where T : class
        {
            if (repositories == null)
            {
                repositories = new Dictionary<string, object>();
            }
            var type = typeof(T).Name;
            if (!repositories.ContainsKey(type))
            {
                var repositoryType = typeof(Repository<>);
                var repositoryInstance = Activator.CreateInstance(repositoryType.MakeGenericType(typeof(T)), dbContext);
                repositories.Add(type, repositoryInstance);
            }
            return (Repository<T>)repositories[type];
        }

    }
}
