﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Web;

namespace Utility
{
    public static class AppSettings
    {
        #region Login
        public static string LoginType
        {
            get
            {
                return Setting<string>("LoginType");
            }
        }
        public static string MaxFailedAccessAttemptsBeforeLockout
        {
            get
            {
                return Setting<string>("MaxFailedAccessAttemptsBeforeLockout");
            }
        }
        public static string DefaultAccountLockoutTimeSpan
        {
            get
            {
                return Setting<string>("DefaultAccountLockoutTimeSpan");
            }
        }
        #endregion

        #region Google Recaptcha
        public static string GoogleRecaptchaSiteKey
        {
            get
            {
                return Setting<string>("data-site-key");
            }
        }
        public static string GoogleRecaptchaSecretKey
        {
            get
            {
                return Setting<string>("data-secret-key");
            }
        }
        #endregion

        #region Social Logins
        public static string FacebookAppId
        {
            get
            {
                return Setting<string>("FacebookAppId");
            }
        }
        public static string FacebookSecretKey
        {
            get
            {
                return Setting<string>("FacebookSecretKey");
            }
        }
        public static string GoogleAppId
        {
            get
            {
                return Setting<string>("GoogleAppId");
            }
        }
        public static string GoogleSecretKey
        {
            get
            {
                return Setting<string>("GoogleSecretKey");
            }
        }
        public static string LinkedInAppId
        {
            get
            {
                return Setting<string>("LinkedInAppId");
            }
        }
        public static string LinkedInSecretKey
        {
            get
            {
                return Setting<string>("LinkedInSecretKey");
            }
        }
        public static string MicrosoftAppId
        {
            get
            {
                return Setting<string>("MicrosoftAppId");
            }
        }
        public static string MicrosoftSecretKey
        {
            get
            {
                return Setting<string>("MicrosoftSecretKey");
            }
        }
        public static string TwitterAppId
        {
            get
            {
                return Setting<string>("TwitterAppId");
            }
        }
        public static string TwitterSecretKey
        {
            get
            {
                return Setting<string>("TwitterSecretKey");
            }
        }
        #endregion

        #region Error
        public static bool ShowCustomErrorPage
        {
            get
            {
                return Setting<bool>("ShowCustomErrorPage");
            }
        }
        #endregion

        #region Crypto Encrypt
        public static string EncryptionKey
        {
            get
            {
                return Setting<string>("EncryptionKey");
            }
        }
        public static string DecryptionKey
        {
            get
            {
                return Setting<string>("DecryptionKey");
            }
        }
        public static bool IsEncrypted
        {
            get
            {
                return Setting<bool>("IsEncrypted");
            }
        }
        #endregion

        #region Okta
        public static string OktaDomain
        {
            get
            {
                return Setting<string>("okta:Domain");
            }
        }
        public static string OktaClientId
        {
            get
            {
                return Setting<string>("okta:ClientId");
            }
        }
        public static string OktaClientSecret
        {
            get
            {
                return Setting<string>("okta:ClientSecret");
            }
        }
        public static string OktaRedirectUri
        {
            get
            {
                return Setting<string>("okta:RedirectUri");
            }
        }
        public static string OktaPostLogoutRedirectUri
        {
            get
            {
                return Setting<string>("okta:PostLogoutRedirectUri");
            }
        }
        #endregion

        #region OpenId
        public static string OpenIdAuthority
        {
            get
            {
                return Setting<string>("openid:Authority");
            }
        }
        public static string OpenIdClientId
        {
            get
            {
                return Setting<string>("openid:ClientId");
            }
        }
        public static string OpenIdClientSecret
        {
            get
            {
                return Setting<string>("openid:ClientSecret");
            }
        }
        public static string OpenIdRedirectUri
        {
            get
            {
                return Setting<string>("openid:RedirectUri");
            }
        }
        public static string OpenIdDomain
        {
            get
            {
                return Setting<string>("openid:Domain");
            }
        }
        public static string OpenIdUserInfoClient
        {
            get
            {
                return Setting<string>("openid:UserInfoClient");
            }
        }
        #endregion


        private static T Setting<T>(string name)
        {
            string value = ConfigurationManager.AppSettings[name];

            if (value == null)
            {
                throw new Exception(String.Format("Could not find setting '{0}',", name));
            }

            return (T)Convert.ChangeType(value, typeof(T), CultureInfo.InvariantCulture);
        }

        public static string ConnectionString
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString();
            }

        }
    }
}