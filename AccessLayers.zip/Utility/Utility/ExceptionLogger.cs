﻿using System;
using System.IO;
using System.Web;
using ORM.Models;
using UOW.Implementations;
using DAL.Implementations;

namespace Utility
{
    public class ExceptionLogger
    {
        private UnitOfWork unitOfWork = new UnitOfWork();
        private Repository<ExceptionLog> _exceptionLogRepository;

        private static String exepurl;

        public ExceptionLogger()
        {
            this._exceptionLogRepository = unitOfWork.Repository<ExceptionLog>();
        }

        public void SendExceptionToDB(Exception exdb)
        {
            var exceptionLogs = new ExceptionLog();
            exepurl = HttpContext.Current.Request.Url.ToString();
            exceptionLogs.ExceptionMsg = exdb.ToString();
            exceptionLogs.ExceptionType = exdb.GetType().Name.ToString();
            exceptionLogs.ExceptionURL = exepurl;
            exceptionLogs.ExceptionSource = exdb.StackTrace.ToString().Trim();
            exceptionLogs.ExceptionDate = DateTime.Now;
            _exceptionLogRepository.Insert(exceptionLogs);

        }

        private String ErrorlineNo, Errormsg, extype, exurl, hostIp, ErrorLocation, HostAdd;

        public void SendErrorToText(Exception ex)
        {
            var line = Environment.NewLine + Environment.NewLine;
            ErrorlineNo = ex.StackTrace.Substring(ex.StackTrace.Length - 7, 7);
            Errormsg = ex.GetType().Name.ToString();
            extype = ex.GetType().ToString();
            exurl = HttpContext.Current.Request.Url.ToString();
            ErrorLocation = ex.Message.ToString();
            try
            {
                string filepath = HttpContext.Current.Server.MapPath("~/ExceptionDetailsFile/");  //Text File Path
                if (!Directory.Exists(filepath))
                {
                    Directory.CreateDirectory(filepath);
                }
                filepath = filepath + DateTime.Today.ToString("dd-MM-yy") + ".txt";   //Text File Name
                if (!File.Exists(filepath))
                {
                    File.Create(filepath).Dispose();
                }
                using (StreamWriter sw = File.AppendText(filepath))
                {
                    string error = "Log Written Date:" + " " + DateTime.Now.ToString() + line + "Error Line No :" + " " + ErrorlineNo + line + "Error Message:" + " " + Errormsg + line + "Exception Type:" + " " + extype + line + "Error Location :" + " " + ErrorLocation + line + " Error Page Url:" + " " + exurl + line + "User Host IP:" + " " + hostIp + line;
                    sw.WriteLine("-----------Exception Details on " + " " + DateTime.Now.ToString() + "-----------------");
                    sw.WriteLine("-------------------------------------------------------------------------------------");
                    sw.WriteLine(line);
                    sw.WriteLine(error);
                    sw.WriteLine("--------------------------------*End*------------------------------------------");
                    sw.WriteLine(line);
                    sw.Flush();
                    sw.Close();
                }
            }
            catch (Exception e)
            {
                e.ToString();

            }
        }
    }
}