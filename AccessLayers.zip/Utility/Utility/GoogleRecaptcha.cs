﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Web;

namespace Utility
{
    public static class GoogleRecaptcha
    {
        public static bool ValidateCaptcha(string captchaCode)
        {
            //Validate Google recaptcha here
            var response = captchaCode;
            string secretKey = AppSettings.GoogleRecaptchaSecretKey;
            var client = new WebClient();
            var result = client.DownloadString(string.Format("https://www.google.com/recaptcha/api/siteverify?secret={0}&response={1}", secretKey, response));
            var obj = Newtonsoft.Json.Linq.JObject.Parse(result);
            var status = (bool)obj.SelectToken("success");
            //ViewBag.Message = status ? "Google reCaptcha validation success" : "Google reCaptcha validation failed";
            return status;
        }
    }
}