﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net.Configuration;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Utility
{
    public static class Mailer
    {

        public static async Task SendMailAsync(string emailTo, string subject, AlternateView avHtml, string body)
        {
            try
            {
                SmtpSection smtpSection = (SmtpSection)ConfigurationManager.GetSection("system.net/mailSettings/smtp");
                string from = smtpSection.From;
                string host = smtpSection.Network.Host;
                int port = smtpSection.Network.Port;
                bool enableSsl = smtpSection.Network.EnableSsl;
                string user = smtpSection.Network.UserName;
                string password = smtpSection.Network.Password;
                SmtpClient client = new SmtpClient(host);
                var ToEmail = emailTo;
                client.Port = port;
                MailMessage message = new MailMessage();
                message.From = new MailAddress(smtpSection.From);
                message.To.Add(ToEmail);
                message.Subject = subject;
                message.Body = body;
                if (avHtml != null)
                {
                    message.AlternateViews.Add(avHtml);
                }
                message.IsBodyHtml = true;
                //message.BodyTransferEncoding = System.Net.Mime.TransferEncoding.Base64;
                //message.IsBodyHtml = true;
                //message.BodyEncoding = System.Text.Encoding.UTF8;
                await client.SendMailAsync(message);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        #region Mail helper
        
        public static string ReadTemplate(string path)
        {
            string body = string.Empty;
            using (StreamReader reader = new StreamReader(System.Web.HttpContext.Current.Server.MapPath(path)))
            {
                body = reader.ReadToEnd();
            }
            return body;
        }

        #endregion

        
    }
}
