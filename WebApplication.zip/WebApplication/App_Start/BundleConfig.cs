﻿using System.Web;
using System.Web.Optimization;

namespace WebApplication
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.validate*"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                      "~/Scripts/bootstrap.js",
                      "~/Scripts/respond.js"));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                      "~/Content/bootstrap.css",
                      "~/Content/site.css"));

            bundles.Add(new StyleBundle("~/Content/admin-css").Include(
                     "~/Areas/Admin/content/bootstrap/css/bootstrap.min.css",
                     "~/Areas/Admin/content/bootstrap/css/bootstrap-responsive.min.css",
                     "~/Areas/Admin/content/css/theme.css",
                     "~/Areas/Admin/Content/css/style.css",
                     "~/Areas/Admin/content/images/icons/css/font-awesome.css"
                     ));

            bundles.Add(new ScriptBundle("~/bundles/admin-jquery").Include(
                    "~/Areas/Admin/Content/scripts/jquery-1.9.1.min.js"
                    ));

            bundles.Add(new ScriptBundle("~/bundles/admin-js").Include(
                     "~/Areas/Admin/Content/scripts/shared.js",
                     "~/Areas/Admin/content/scripts/jquery-ui-1.10.1.custom.min.js",
                     "~/Areas/Admin/content/bootstrap/js/bootstrap.min.js",
                     //"~/Areas/Admin/content/scripts/flot/jquery.flot.js",
                     "~/Areas/Admin/content/scripts/datatables/jquery.dataTables.js"                     
                     ));
        }
    }
}
