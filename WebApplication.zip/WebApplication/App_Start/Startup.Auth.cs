﻿using Microsoft.AspNet.Identity;
using Microsoft.Owin;
using Microsoft.Owin.Security.Cookies;
using Owin;
using Okta.AspNet;
using System.Configuration;
using System.Collections.Generic;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.OpenIdConnect;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using IdentityModel.Client;
using System;
using System.Threading.Tasks;
using System.Security.Claims;
using System.Net;
using Utility;
using WebApplication.Extensions;
using Microsoft.Owin.Security.DataProtection;
using System.Web;
using Microsoft.Owin.Security.Notifications;

namespace WebApplication
{
    public partial class Startup
    {
        // For more information on configuring authentication, please visit http://go.microsoft.com/fwlink/?LinkId=301864
        internal static IDataProtectionProvider DataProtectionProvider { get; private set; }
        public void ConfigureAuth(IAppBuilder app)
        {
            DataProtectionProvider = app.GetDataProtectionProvider();
            // Enable the application to use a cookie to store information for the signed in user
            app.UseCookieAuthentication(new CookieAuthenticationOptions
            {
                AuthenticationType = DefaultAuthenticationTypes.ApplicationCookie,
                LoginPath = new PathString("/Account/Login")
            });
            // Use a cookie to temporarily store information about a user logging in with a third party login provider
            app.UseExternalSignInCookie(DefaultAuthenticationTypes.ExternalCookie);

            // Uncomment the following lines to enable logging in with third party login providers
            //app.UseMicrosoftAccountAuthentication(
            //    clientId: AppSettings.MicrosoftAppId,
            //    clientSecret: AppSettings.MicrosoftSecretKey);

            //app.UseTwitterAuthentication(
            //   consumerKey: AppSettings.TwitterAppId,
            //   consumerSecret: AppSettings.TwitterSecretKey);

            //app.UseFacebookAuthentication(
            //   appId: AppSettings.FacebookAppId,
            //   appSecret: AppSettings.FacebookSecretKey);

            //app.UseGoogleAuthentication(
            //    clientId: AppSettings.GoogleAppId,
            //    clientSecret: AppSettings.GoogleSecretKey
            //    );

            //app.UseLinkedInAuthentication(new LinkedInAuthenticationOptions()
            //{
            //    ClientId = AppSettings.LinkedInAppId,
            //    ClientSecret = AppSettings.LinkedInSecretKey,
            //});

            if (AppSettings.LoginType != "internal")
            {
                app.SetDefaultSignInAsAuthenticationType(CookieAuthenticationDefaults.AuthenticationType);
                app.UseCookieAuthentication(new CookieAuthenticationOptions());
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            }

            if (AppSettings.LoginType == "okta")
            {
                app.UseOktaMvc(new OktaMvcOptions()
                {
                    OktaDomain = AppSettings.OktaDomain,
                    ClientId = AppSettings.OktaClientId,
                    ClientSecret = AppSettings.OktaClientSecret,
                    RedirectUri = AppSettings.OktaRedirectUri,
                    PostLogoutRedirectUri = AppSettings.OktaPostLogoutRedirectUri,
                    Scope = new List<string> { "openid", "profile", "email" },

                });
            }
            if (AppSettings.LoginType == "openid")
            {
                app.UseOpenIdConnectAuthentication(new OpenIdConnectAuthenticationOptions()
                    {
                        ClientId = AppSettings.OpenIdClientId,
                        ClientSecret = AppSettings.OpenIdClientSecret,
                        Authority = AppSettings.OpenIdAuthority,
                        Scope = "openid profile email",
                        RedirectUri = AppSettings.OpenIdRedirectUri,
                        ResponseType = OpenIdConnectResponseType.Code,

                        TokenValidationParameters = new TokenValidationParameters { NameClaimType = "name" },
                        Notifications = new OpenIdConnectAuthenticationNotifications
                        {
                            AuthorizationCodeReceived = async n =>
                            {
                                // Exchange code for access and ID tokens
                                var tokenClient = new TokenClient(AppSettings.OpenIdDomain, AppSettings.OpenIdClientId, AppSettings.OpenIdClientSecret);
                                var tokenResponse = await tokenClient.RequestAuthorizationCodeAsync(n.Code, AppSettings.OpenIdRedirectUri);
                                if (tokenResponse.IsError)
                                {
                                    throw new Exception(tokenResponse.Error);
                                }
                                SetCookie(tokenResponse.AccessToken);
                            },
                        },
                    });
            }
        }

        private Task OnAuthenticationFailed(AuthenticationFailedNotification<OpenIdConnectMessage, OpenIdConnectAuthenticationOptions> context)
        {
            context.HandleResponse();
            context.Response.Redirect("/?errormessage=" + context.Exception.Message);
            return Task.FromResult(0);
        }

        private void SetCookie(string val)
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies["t"];
            if (cookie != null)
            {
                cookie.Value = val;
            }// update cookie value
            else
            {
                cookie = new HttpCookie("t");
                cookie.Value = val;
            }
            HttpContext.Current.Response.Cookies.Add(cookie);
        }
    }
}