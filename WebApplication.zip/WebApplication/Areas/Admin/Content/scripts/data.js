﻿function CreateTable(url, tableid) {
    //$('#myDataTable').dataTable().fnDestroy();
    var oTable = $('#' + tableid).dataTable({
        //"dom": 'Bfrtip',
        lengthMenu: [[25, 100, 200, 1000000000], [25, 100, 200, "All"]],
        "bInfo": true,
        "sLoadingRecords": "Loading...",
        "sProcessing": "Processing...",
        "bServerSide": true,
        "ajax": {
            "url": url,
            "type": "Post",
            "datatype": "json",
            "data": function (d) {
                //var titleFilter = $('#drpTitleFilter').val();
                //d.titleFilter = titleFilter;
            },

        },
        //"sAjaxSource": url,
        "order": [[1, "desc"]],
        "bProcessing": true,
        "aoColumns": [
                        {
                            "sName": "UserGroupID",
                            "bSearchable": false,
                            "bSortable": false,
                            "bVisible": false,
                            orderable: false,
                        },
			            { "sName": "UserGroup" },
			            { "sName": "CreatedOn" },
			            { "sName": "Active" },
                         {
                             orderable: false,

                             render: function (data, type, row) {
                                 return '<a class="btn btn-primary edit">' +
                                     '<span class="glyphicon glyphicon-pencil"> </span>' +
                                     '</a>'

                             }

                         },
                         {
                             render: function (data, type, row) {
                                 return '<a class="btn btn-danger delete">' +
                                   '<span class="glyphicon glyphicon-trash"> </span>' +
                                   '</a>'

                             }

                         }

        ]
    });
}


var GenerateTable = function (url, tableid) {

    $.ajax({
        url: url,
        type: 'POST',
        data: function (d) { },
        success: function (response) {
            //if (response.data != true) {
            //    console.log("Exception", response);
            //    alert('There is some error has occured!. Please see in console for details of error');
            //}
            //else {

                //Handling JQuery Datatable Dynamically...
                //Check Data Table has if already initialize then need to destroy first!
                //if ($.fn.DataTable.isDataTable('#' + tableid)) {
                //    $('#' + tableid).DataTable().destroy();
                //    $('#' + tableid).empty();
                //}
                //Listing Columns (Table Header) from json ajax response
                var Columns = [];
                var TableHeader = "<thead><tr>";
                $.each(response.data, function (key, value) {
                    Columns.push({ "data": value })
                    TableHeader += "<th>" + value + "</th>"
                });
                TableHeader += "</thead></tr>";
                $('#' + tableid).append(TableHeader);
                $('#' + tableid).dataTable({
                    "oLanguage": {
                        "sLengthMenu": "_MENU_ &nbsp;"
                    },
                    "data": response.data,
                    "columns": Columns,
                    "JQueryUI": true,
                    dom: 'Bfrtip',
                    dom: 'lBfrtip',
                    lengthMenu: [[25, 100, 200, 1000000000], [25, 100, 200, "All"]],
                    "bInfo": true,
                    "sLoadingRecords": "Loading...",
                    "sProcessing": "Processing...",
                });
            }
        //}
    });
}