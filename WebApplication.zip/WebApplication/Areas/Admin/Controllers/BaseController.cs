﻿using BAL.Implementations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication.Areas.Admin.Models;
//using System.Linq.Dynamic;

namespace WebApplication.Areas.Admin.Controllers
{
    public abstract class BaseController : Controller
    {
        protected ExceptionsBAL objExceptionsBAL = new ExceptionsBAL();

        public BaseController()
        {
           
        }
        protected IEnumerable<T> SortColumns<T>(JQDataTableParamModel param, IEnumerable<T> obj)
        {
            //obj = obj.OrderBy(param.columns[param.order[0].column].name + " " + param.order[0].dir);
            return obj;
        }
	}
}