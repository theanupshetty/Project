﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace WebApplication.Areas.Admin.Models
{
    public class DataTableModel
    {
        private List<String> _Header;

        private String _JsonHeader;

        public String TableId { get; set; }
        public List<String> Header
        {
            get { return _Header; }

            set
            {
                _Header = value;

                StringBuilder headerProperty = new StringBuilder();
                headerProperty.Append("[");
                foreach (var item in Header)
                {
                    headerProperty.Append("{ 'mData': '" + item + "', sDefaultContent: '' },");
                }
                headerProperty.Append("]");

                _JsonHeader = headerProperty.ToString().Replace(",]", "]");
            }
        }

        public String JsonData { get; set; }

        public String JsonHeader { get { return _JsonHeader; } }
    }

    public class JQDataTableParamModel
    {
        public string sortDirection { get; set; }
        public int draw { get; set; }
        public int start { get; set; }
        public int length { get; set; }
        public List<Column> columns { get; set; }
        public Search search { get; set; }
        public List<Order> order { get; set; }
        public string sActive { get; set; }
        public string dateRange { get; set; }
        public string countryFilter { get; set; }
        public string professionFilter { get; set; }
        public string titleFilter { get; set; }
        public string assetSectionFilter { get; set; }
        public string assetSubSectionFilter { get; set; }
        public string trackTypeFilter { get; set; }
        public string emailFilter { get; set; }

    }

    public class Column
    {
        public string data { get; set; }
        public string name { get; set; }
        public bool searchable { get; set; }
        public bool orderable { get; set; }
        public Search search { get; set; }
    }

    public class Search
    {
        public string value { get; set; }
        public string regex { get; set; }
    }

    public class Order
    {
        public int column { get; set; }
        public string dir { get; set; }
    }

    public class DataViewModel
    {
        public DataTableModel DataTableModel { get; set; }
    }
}