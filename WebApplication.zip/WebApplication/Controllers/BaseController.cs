﻿using BAL.Implementations;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using Utility;
using WebApplication.Filters;
using WebApplication.Extensions;
using WebApplication.Models;

namespace WebApplication.Controllers
{
    [HandleError]
    [RequireHttps]
    [CompressFilter]
    [OutputCache(Duration = 3600, VaryByParam = "none", Location = System.Web.UI.OutputCacheLocation.Server)]
    public abstract class BaseController : Controller
    {
        protected string cultureName = null;
        protected string userId = null;
        protected string userName = null;

        protected NotificationsBAL objNotificationBAL = new NotificationsBAL();

        public BaseController()
            : this(new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(new ApplicationDbContext())))
        {
            UserManager.UserValidator = new UserValidator<ApplicationUser>(UserManager)
            {
                AllowOnlyAlphanumericUserNames = false,
                RequireUniqueEmail = true
            };
            var dataProtectionProvider = Startup.DataProtectionProvider;
            UserManager.UserTokenProvider =
                    new DataProtectorTokenProvider<ApplicationUser>(dataProtectionProvider.Create("ASP.NET Identity"))
                    {
                        TokenLifespan = TimeSpan.FromHours(24)
                    };
            UserManager.UserLockoutEnabledByDefault = true;
            UserManager.DefaultAccountLockoutTimeSpan = TimeSpan.FromMinutes(30);
            UserManager.MaxFailedAccessAttemptsBeforeLockout = 5;
        }

        public BaseController(UserManager<ApplicationUser> userManager)
        {
            UserManager = userManager;
        }

        public UserManager<ApplicationUser> UserManager { get; protected set; }

       
        static BaseController()
        {
            ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 |
                                                 SecurityProtocolType.Tls11 |
                                                 SecurityProtocolType.Tls |
                                                 SecurityProtocolType.Ssl3;
        }

        protected override IAsyncResult BeginExecuteCore(AsyncCallback callback, object state)
        {
            // Attempt to read the culture cookie from Request
            cultureName = Culture.GetImplementedCulture(); // Get current culture
            // Modify current thread's cultures            
            Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo(cultureName);
            Thread.CurrentThread.CurrentUICulture = Thread.CurrentThread.CurrentCulture;
            return base.BeginExecuteCore(callback, state);
        }

        protected override void OnActionExecuted(ActionExecutedContext filterContext)
        {

            if (User.Identity.IsAuthenticated)
            {
                var context = new ApplicationDbContext();
                userName = User.Identity.Name;
                userId = User.Identity.GetUserId();
                ApplicationUser user = null;
                if (!string.IsNullOrEmpty(userName))
                {
                    var isEmailValid = new EmailAddressAttribute().IsValid(userName);
                    if (isEmailValid)
                    {
                        user = UserManager.FindByEmail(userName);

                    }
                    else
                    {
                        user = UserManager.FindByName(userName);
                    }

                }

                if (user != null)
                {
                    ViewData.Add("FullName", user.FirstName +" "+ user.LastName);

                    if (user.Logins.Count() > 0)
                    {
                        ViewData.Add("HasSocialLogin", true);
                    }
                    if (UserIsInAnyRole(user.Id))
                    {
                        ViewData.Add("Role", true);
                    }
                }

            }


            base.OnActionExecuted(filterContext);
        }


        protected override void OnException(ExceptionContext filterContext)
        {
            base.OnException(filterContext);
        }

        [HttpPost]
        public ActionResult SetCulture(string culture)
        {
            HttpCookie cookie = Request.Cookies["_culture"];
            if (cookie != null)
            {
                cookie.Value = culture;
            }// update cookie value
            else
            {
                cookie = new HttpCookie("_culture");
                cookie.Value = culture;
                cookie.Expires = DateTime.Now.AddYears(1);
            }
            Response.Cookies.Add(cookie);
            return Json(true, JsonRequestBehavior.AllowGet);
        }

        private bool UserIsInAnyRole(string id)
        {
            var roles = UserManager.GetRoles(id);
            if (roles.Count() > 0)
            {
                return true;
            }
            return false;
        }
    }
}