﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication.Filters;

namespace WebApplication.Controllers
{
    [ETagFilter]
    public class ErrorController : Controller
    {
        public ErrorController()
        {

        }
        [AllowAnonymous]
        public ActionResult Index()
        {
            return View();

        }

        [AllowAnonymous]
        public ActionResult NotFound()
        {
            return View();
        }

        [AllowAnonymous]
        public ActionResult AccessDenied()
        {
            return View();
        }

        [AllowAnonymous]
        public ActionResult HttpError404()
        {
            return View("~/Views/Error/HttpError401.cshtml");
        }
        [AllowAnonymous]
        public ActionResult HttpError403()
        {
            return View("~/Views/Error/HttpError403.cshtml");
        }

        [AllowAnonymous]
        public ActionResult HttpError500()
        {
            return View("~/Views/Error/HttpError500.cshtml");
        }
        [AllowAnonymous]
        public ActionResult HttpError401()
        {
            return View("~/Views/Error/HttpError401.cshtml");
        }

        [AllowAnonymous]
        public ActionResult SessionTimeOut()
        {

            return View("~/Views/Error/SessionTimeOut.cshtml");
        }
        [AllowAnonymous]
        public ActionResult ErrorPage(string redirectMSG)
        {
            if (!string.IsNullOrEmpty(redirectMSG))
            {
                ViewBag.redirectMSG = redirectMSG;
            }
            return View("~/Views/Error/ErrorPage.cshtml");

        }
        public ActionResult RegistrationExpires()
        {
            return View();
        }
        public ActionResult ResetPasswordExpired()
        {
            return View();
        }
        /// <summary>
        /// Created for the HttpError403 Page 
        /// </summary>
        /// <param name="error"></param>
        /// <returns>HttpError403 page</returns>
        public ActionResult HttpError403(string error)
        {
            ViewBag.Description = error;
            return this.View();
        }

        [AllowAnonymous]
        public ActionResult Error()
        {
            return View("~/Views/Error/Error.cshtml");
        }

        [AllowAnonymous]
        public ActionResult ConcurrentSession()
        {

            return View();
        }

    }

}