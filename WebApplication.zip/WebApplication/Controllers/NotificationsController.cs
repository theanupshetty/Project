﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication.Hubs;
using Microsoft.AspNet.Identity;
using System.Threading.Tasks;

namespace WebApplication.Controllers
{
    [Authorize]
    public class NotificationsController : BaseController
    {

        public JsonResult GetNotifications()
        {
            NotificationsRepository _notificationsRepository = new NotificationsRepository();
            var list = _notificationsRepository.GetNotification(userId).OrderByDescending(x => x.Id).Take(10);
            return Json(list, JsonRequestBehavior.AllowGet);
        }

        public JsonResult UpdateNotifications()
        {
            objNotificationBAL.UpdateMany(userId);
            return Json(true, JsonRequestBehavior.AllowGet);
        }

        public async Task<JsonResult> ClearNotifications()
        {
            var notifications = objNotificationBAL.Get(userId).OrderByDescending(x => x.Id).Take(10).ToList();
            await objNotificationBAL.DeleteManyAsync(notifications);
            return Json(true, JsonRequestBehavior.AllowGet);
        }
    }
}