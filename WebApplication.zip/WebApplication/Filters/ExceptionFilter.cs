﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace WebApplication.Filters
{
    public class ExceptionFilter : AuthorizeAttribute
    {
        /// <summary>
        /// Created for the custom action filter
        /// </summary>

        /// <summary>
        /// Override the unauthorised page redirection
        /// </summary>
        /// <param name="filterContext"></param>
        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            //set the route url
            filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary 
            {
                { "action", "ErrorPage" },
                { "controller", "Error" },
                {"redirectMSG", "Oops! Page not found."},
                { "returnUrl", filterContext.HttpContext.Request.RawUrl}             


            });
        }


    }

}