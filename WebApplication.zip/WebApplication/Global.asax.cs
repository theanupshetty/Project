﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Claims;
using System.Web;
using System.Web.Helpers;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using Utility;
using WebApplication.Extensions;

namespace WebApplication
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_BeginRequest(Object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.Now.AddSeconds(-1));
            Response.Cache.SetNoStore();

            if (HttpContext.Current.Request.IsSecureConnection.Equals(false)
               && HttpContext.Current.Request.IsLocal.Equals(false))
            {

                Response.Redirect("https://" + Request.ServerVariables["HTTP_HOST"] + HttpContext.Current.Request.RawUrl);
            }
            if (HttpContext.Current.Request.IsLocal.Equals(false))
            {
                BundleTable.EnableOptimizations = true;
            }
            else
            {
                //For debugging
                foreach (var bundle in BundleTable.Bundles)
                {
                    bundle.Transforms.Clear();
                }
            }

        }

        protected void Application_Start()
        {
            ViewEngines.Engines.Clear();
            ViewEngines.Engines.Add(new RazorViewEngine());
            ConfigureAntiForgeryTokens();
            MvcHandler.DisableMvcResponseHeader = true;
            AntiForgeryConfig.SuppressXFrameOptionsHeader = true;
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            SqlDependency.Start(AppSettings.ConnectionString);
        }

        protected void Application_PreSendRequestHeaders()
        {
            Response.Headers.Remove("Server");
            Response.Headers.Remove("X-AspNet-Version");
            Response.Headers.Remove("X-AspNetMvc-Version");
        }

        protected void Application_End()
        {
            //Stop SQL dependency
            SqlDependency.Stop(AppSettings.ConnectionString);
        }
        protected void Application_EndRequest()
        {
            //var context = new HttpContextWrapper(Context);
            //if (context.Response.StatusCode == 401)
            //{
            //    var urlHelper = new UrlHelper(HttpContext.Current.Request.RequestContext);
            //    Response.Redirect(urlHelper.Action("httperror401", "error"));

            //}

        }

        protected void Application_Error()
        {
            Exception exception = Server.GetLastError();
            Response.Clear();
            HttpException httpException = exception as HttpException;
            ExceptionLogger logger = new ExceptionLogger();
            logger.SendErrorToText(exception);
            logger.SendExceptionToDB(exception);

            if (AppSettings.ShowCustomErrorPage)
            {
                if (httpException != null)
                {
                    string action;

                    switch (httpException.GetHttpCode())
                    {
                        case 404:
                            // page not found
                            action = "HttpError404";
                            break;
                        case 403:
                            // page not found
                            action = "HttpError403";
                            break;
                        case 500:
                            // server error
                            action = "HttpError500";
                            break;
                        case 401:
                            // page not found
                            action = "HttpError401";
                            break;
                        default:
                            action = "Error";
                            break;
                    }
                    // clear error on server
                    Server.ClearError();
                    //var urlHelper = new UrlHelper(HttpContext.Current.Request.RequestContext);
                    Response.Redirect(String.Format("~/Error/{0}", action));

                }
                else
                {
                    Response.Redirect("~/Error/Error");
                }
            }
        }

        private static void ConfigureAntiForgeryTokens()
        {
            // Rename the Anti-Forgery cookie from "__RequestVerificationToken" to "f". This adds a little security 
            // through obscurity and also saves sending a few characters over the wire. Sadly there is no way to change 
            // the form input name which is hard coded in the @Html.AntiForgeryToken helper and the 
            // ValidationAntiforgeryTokenAttribute to  __RequestVerificationToken.
            //<input name="__RequestVerificationToken" type="hidden" value="..." />

            AntiForgeryConfig.UniqueClaimTypeIdentifier = ClaimsIdentity.DefaultNameClaimType;
            AntiForgeryConfig.CookieName = "f";

            // If you have enabled SSL. Uncomment this line to ensure that the Anti-Forgery 
            // cookie requires SSL to be sent across the wire. 

            AntiForgeryConfig.RequireSsl = true;
        }
    }
}
