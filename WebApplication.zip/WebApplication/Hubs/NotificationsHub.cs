﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;
using System.Configuration;

namespace WebApplication.Hubs
{
    public class NotificationsHub : Hub
    {

        [HubMethodName("sendNotifications")]
        public static void SendNotifications()
        {
            IHubContext context = GlobalHost.ConnectionManager.GetHubContext<NotificationsHub>();
            context.Clients.All.updateNotifications();
        }

       
    }


}