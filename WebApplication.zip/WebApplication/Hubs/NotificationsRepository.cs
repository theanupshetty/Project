﻿using Microsoft.AspNet.SignalR;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using Microsoft.AspNet.Identity;
using Utility;
using ORM.Models;

namespace WebApplication.Hubs
{
    [Authorize]
    public class NotificationsRepository
    {
        static bool isEncrypt = AppSettings.IsEncrypted;
        readonly string _connString = (isEncrypt == true) ? Utility.Crypto.Decrypt(AppSettings.ConnectionString) : AppSettings.ConnectionString;

        public IEnumerable<Notification> GetNotification(string userid)
        {
            var notifications = new List<Notification>();
           
            using (var connection = new SqlConnection(_connString))
            {
                try
                {
                    connection.Open();
                    string sqlCommand = @"SELECT [Id],[UserId],[Message],[Url],[Type],[CreatedDate],[IsRead] from [dbo].[Notifications] where [UserId] = @UserId";

                    using (var command = new SqlCommand(sqlCommand, connection))
                    {
                        command.Parameters.AddWithValue("@UserId", userid);
                        command.Notification = null;

                        var dependency = new SqlDependency(command);
                        dependency.OnChange += new OnChangeEventHandler(dependency_OnChange);


                        if (connection.State == ConnectionState.Closed)
                            connection.Open();

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                notifications.Add(item: new Notification { Id = (int)reader[0], UserId = (string)reader[1], Message = reader[2] != DBNull.Value ? (string)reader[2] : "", IsRead = (bool)reader[6], Url = reader[3] != DBNull.Value ? (string)reader[3] : "" });

                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    connection.Close();
                }

            }
            return notifications;
        }

        private void dependency_OnChange(object sender, SqlNotificationEventArgs e)
        {
            if (e.Type == SqlNotificationType.Change && e.Info == SqlNotificationInfo.Insert)
            {
                NotificationsHub.SendNotifications();
            }
        }

    }
}