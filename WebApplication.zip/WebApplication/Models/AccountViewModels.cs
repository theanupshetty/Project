﻿using System.ComponentModel.DataAnnotations;
using WebApplication.App_GlobalResources;

namespace WebApplication.Models
{
    public class ExternalLoginConfirmationViewModel
    {
        [Required]
        [Display(Name = "User name")]
        public string UserName { get; set; }
    }

    public class ManageUserViewModel
    {
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Current password")]
        public string OldPassword { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "New password")]
        public string NewPassword { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm new password")]
        [Compare("NewPassword", ErrorMessage = "The new password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }
    }

    public class LoginViewModel
    {
        [Required(ErrorMessageResourceType = typeof(Resource), ErrorMessageResourceName = "AccountEmailRequired")]
        [Display(Name = "AccountEmailLabel", ResourceType = typeof(Resource))]
        [DataType(DataType.EmailAddress, ErrorMessageResourceType = typeof(Resource), ErrorMessageResourceName = "AccountValidEmail")]
        [RegularExpression(@"^[\w-]+(\.[\w-]+)*@([a-z0-9-]+(\.[a-z0-9-]+)*?\.[a-z]{2,6}|(\d{1,3}\.){3}\d{1,3})(:\d{4})?$", ErrorMessageResourceType = typeof(Resource), ErrorMessageResourceName = "AccountValidEmail")]
        public string Email { get; set; }

        [Required(ErrorMessageResourceType = typeof(Resource), ErrorMessageResourceName = "AccountPasswordRequired")]
        [DataType(DataType.Password)]
        [Display(Name = "AccountPasswordLabel", ResourceType = typeof(Resource))]
        public string Password { get; set; }

        [Display(Name = "AccountRememberMeLabel", ResourceType = typeof(Resource))]
        public bool RememberMe { get; set; }
    }

    public class RegisterViewModel
    {
        [Required(ErrorMessageResourceType = typeof(Resource), ErrorMessageResourceName = "AccountEmailRequired")]
        [Display(Name = "AccountEmailLabel", ResourceType = typeof(Resource))]
        [DataType(DataType.EmailAddress, ErrorMessageResourceType = typeof(Resource), ErrorMessageResourceName = "AccountValidEmail")]
        [RegularExpression(@"^[\w-]+(\.[\w-]+)*@([a-z0-9-]+(\.[a-z0-9-]+)*?\.[a-z]{2,6}|(\d{1,3}\.){3}\d{1,3})(:\d{4})?$", ErrorMessageResourceType = typeof(Resource), ErrorMessageResourceName = "AccountValidEmail")]
        public string Email { get; set; }

        [Required(ErrorMessageResourceType = typeof(Resource), ErrorMessageResourceName = "AccountFirstNameRequired"), MaxLength(20, ErrorMessageResourceType = typeof(Resource), ErrorMessageResourceName = "AccountNameMaxLengthError")]
        [Display(Name = "AccountFirstName", ResourceType = typeof(Resource))]
        [RegularExpression(@"^[A-z]+$", ErrorMessageResourceType = typeof(Resource), ErrorMessageResourceName = "AccountNameValidError")]
        public string FirstName { get; set; }

        [Required(ErrorMessageResourceType = typeof(Resource), ErrorMessageResourceName = "AccountLastNameRequired"), MaxLength(20, ErrorMessageResourceType = typeof(Resource), ErrorMessageResourceName = "AccountNameMaxLengthError")]
        [Display(Name = "AccountLastName", ResourceType = typeof(Resource))]
        [RegularExpression(@"^[A-z]+$", ErrorMessageResourceType = typeof(Resource), ErrorMessageResourceName = "AccountNameValidError")]
        public string LastName { get; set; }

     
        [StringLength(100, ErrorMessageResourceType = typeof(Resource), ErrorMessageResourceName = "AccountPasswordLengthError", MinimumLength = 8)]
        [Required(ErrorMessageResourceType = typeof(Resource), ErrorMessageResourceName = "AccountPasswordRequired")]
        [DataType(DataType.Password)]
        [Display(Name = "AccountPasswordLabel", ResourceType = typeof(Resource))]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "AccountConfirmPasswordLabel", ResourceType = typeof(Resource))]
        [Compare("Password", ErrorMessageResourceType = typeof(Resource), ErrorMessageResourceName = "AccountConfirmPasswordRequired")]
        public string ConfirmPassword { get; set; }
    }
}
